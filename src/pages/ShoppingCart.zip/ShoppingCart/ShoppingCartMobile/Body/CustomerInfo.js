import React, { Component } from "react";
import { Input, Checkbox } from "antd";

export default class CustomerInfo extends Component {
    render() {
        return (
            <div className="bodyPageCustomerInfo">
                <div className="inputInfo">
                    <div className="input">
                        <span>Tên người nhận</span>
                        <Input placeholder="Nhập họ & tên người nhận " />
                    </div>
                    <div className="input">
                        <span>Số điện thoại</span>
                        <Input placeholder="Nhập số điện thoại nhận hàng " />
                    </div>
                    <div className="input">
                        <span>Địa chỉ nhận hàng</span>
                        <Input placeholder="Nhập số nhà, tên đường... " />
                    </div>
                </div>
                <div className="checkBox">
                    <Checkbox>
                        <span className="content">Lưu thông tin cho lần đặt may tới</span>
                    </Checkbox>
                </div>
            </div>
        );
    }
}
