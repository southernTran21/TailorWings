import React, { Component } from "react";
import { Radio } from "antd";

export default class PaymentConfirm extends Component {
    render() {
        return (
            <div className="bodyPagePaymentConfirm">
                <div className="address">
                    <div className="titleHead d-flex justify-content-between align-items-center">
                        <span>Địa chỉ nhận hàng</span>
                        <span>THAY ĐỔI</span>
                    </div>
                    <div className="content d-flex flex-column">
                        <span>DUONG DINH DONG KHOA - 0939920405</span>
                        <span>
                            103A NGUYEN VAN LAC, Phường 19, Quận Bình Thạnh, Hồ
                            Chí Minh
                        </span>
                    </div>
                </div>
                <div className="selectPayment">
                    <div className="titleHead d-flex justify-content-between align-items-center">
                        <span>Chọn hình thức thanh toán</span>
                    </div>
                    <div className="content d-flex flex-column">
                        <div className="selection d-flex flex-column justify-content-center">
                            <Radio>Thanh toán khi nhận hàng (COD)</Radio>
                        </div>
                        <div className="selection d-flex flex-column justify-content-center">
                            <Radio>Thanh toán chuyển khoản</Radio>
                        </div>
                    </div>
                </div>
                <div className="info">
                    <div className="titleHead d-flex justify-content-between align-items-center">
                        <span>Thông tin đơn hàng</span>
                        <span>THAY ĐỔI</span>
                    </div>
                    <div className="content d-flex flex-column">
                        <div className="infoProduct d-flex justify-content-between">
                            <div className="d-flex">
                                <div className="image"></div>
                                <div className="titleInfoProduct d-flex flex-column justify-content-between">
                                    <div className='d-flex flex-column'>
                                        <span>Đầm Công Chúa - S</span>
                                        <span>B001C032</span>
                                    </div>
                                    <span>290,000 VND</span>
                                </div>
                            </div>
                            <div className="quantity">
                                <span>x1</span>
                            </div>
                        </div>
                        <div className="infoProduct d-flex justify-content-between">
                            <div className="d-flex">
                                <div className="image"></div>
                                <div className="titleInfoProduct d-flex flex-column justify-content-between">
                                    <div className='d-flex flex-column'>
                                        <span>Đầm Công Chúa - S</span>
                                        <span>B001C032</span>
                                    </div>
                                    <span>290,000 VND</span>
                                </div>
                            </div>
                            <div className="quantity">
                                <span>x1</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='cost d-flex justify-content-between align-items-center'>
                    <span>PHÍ GIAO HÀNG</span>
                    <span>MIỄN PHÍ</span>
                </div>
                <div className='total d-flex align-items-center justify-content-between'>
                    <span>Thành tiền</span>
                    <span>620.000 VNĐ</span>
                </div>
            </div>
        );
    }
}
