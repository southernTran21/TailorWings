import React, { Component } from 'react';
import './home.scss';
import tailor from '../../assets/iconImage/tailorwings.svg';
import { Icon } from 'antd';

// import component
import CarouselStrikingDesign from './CarouselStrikingDesign';
import CarouselCollection from './CarouselCollection';

export default class home extends Component {
    render() {
        return (
            <div className='pageHomeMobile'>
                <div className='navbarHeader d-flex flex-row align-items-center justify-content-between'>
                    <div className='hamburgerMenu'>
                        <Icon type='menu' />
                    </div>
                    <div className='titleHeader'>TAILOR WINGS</div>
                    <div className='iconSearch'>
                        <Icon type='search' />
                    </div>
                </div>
                <div className='bodyPage'>
                    <div className='header__bodyPage'></div>
                    <div className='content__bodyPage d-flex flex-column justify-content-around'>
                        <div className='title d-flex flex-column'>
                            <span>
                                Đặt may giao tận nhà chỉ với 4 bước đơn giản
                            </span>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit. Aenean in nisl in ex varius
                                luctus.
                            </span>
                        </div>
                        <div className='fourStep-wraper d-flex flex-row justify-content-between'>
                            <div className='fourStep-content'>
                                <div className='image'></div>
                                <div className='title'>
                                    <span>Chọn mẫu</span>
                                </div>
                            </div>
                            <div className='fourStep-content'>
                                <div className='image'></div>
                                <div className='title'>
                                    <span>Chọn vải</span>
                                </div>
                            </div>
                            <div className='fourStep-content'>
                                <div className='image'></div>
                                <div className='title'>
                                    <span>Chọn size</span>
                                </div>
                            </div>
                            <div className='fourStep-content'>
                                <div className='image'></div>
                                <div className='title'>
                                    <span>Đặt hàng</span>
                                </div>
                            </div>
                        </div>
                        <hr />
                    </div>
                    <div className='strikingDesign-wraper'>
                        <div className='title d-flex flex-column'>
                            <span>Thiết Kế Nổi Bật</span>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit. Aenean in nisl in ex varius
                                luctus.
                            </span>
                        </div>
                        <CarouselStrikingDesign />
                    </div>
                    <div className='listProduct d-flex flex-column justify-content-between'>
                        <div className='title__listProduct d-flex flex-row justify-content-center'>
                            Danh Mục Sản Phẩm
                        </div>
                        <div className='categoryProduct d-flex flex-row justify-content-between'>
                            <div className='contentProduct d-flex flex-column justify-content-center align-items-center'>
                                <span>Đầm Suông</span>
                                <span>+27 thiết kế</span>
                            </div>
                            <div className='contentProduct d-flex flex-column justify-content-center align-items-center'>
                                <span>Đầm Ôm</span>
                                <span>+14 thiết kế</span>
                            </div>
                            <div className='contentProduct d-flex flex-column justify-content-center align-items-center'>
                                <span>Đầm Xoè</span>
                                <span>+8 thiết kế</span>
                            </div>
                        </div>
                        <hr />
                    </div>
                    <div className='collection-wraper d-flex flex-column justify-content-around'>
                        <div className='title__collection d-flex flex-column'>
                            <span>Bộ Sưu Tập</span>
                            <span>
                                Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit. Aenean in nisl in ex varius
                                luctus.
                            </span>
                        </div>
                        <CarouselCollection />
                        <hr />
                    </div>
                    <div className='weYour-wraper d-flex flex-column justify-content-around'>
                        <div className='title__weyour d-flex flex-column justify-content-center align-items-center'>
                            <span className='title1'>We Tailor Your Wings</span>
                            <span className='text-center title2'>
                                Tự do lựa chọn để thể hiện phong cách của chính
                                bạn.{' '}
                                <span className='font-weight-bold'>
                                    Tất cả có trên cùng một ứng dụng.
                                </span>
                            </span>
                        </div>
                        <div className='image-wraper'>
                            <div className='title d-flex flex-row justify-content-center align-items-center'>
                                Xem thêm <Icon type='arrow-right' />
                            </div>
                        </div>
                    </div>
                    <div className='weGive-wraper'>
                        <div className='title d-flex flex-column justify-content-center align-items-center'>
                            <span>We Give Tailor Wings</span>
                            <span className='text-center'>
                                Trở thành đối tác của Tailor Wings để làm chủ
                                cuộc sống của mình tốt hơn.
                            </span>
                        </div>
                        <div className='fourBenefit-wraper d-flex flex-column justify-content-center align-items-center'>
                            <div className='twoBenefit d-flex flex-row'>
                                <div className='col-6 d-flex flex-column justify-content-center align-items-center'>
                                    <div className='image'></div>
                                    <div className='titleBenefit d-flex flex-column justify-content-center align-items-center'>
                                        <span>Tiếp cận</span>
                                        <span>
                                            Tiếp cận với khách hàng nhanh chóng
                                        </span>
                                    </div>
                                </div>
                                <div className='col-6  d-flex flex-column justify-content-center align-items-center'>
                                    <div className='image'></div>
                                    <div className='titleBenefit d-flex flex-column justify-content-center align-items-center'>
                                        <span>Lợi ích 2</span>
                                        <span>
                                            Tiếp cận với khách hàng nhanh chóng
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className='twoBenefit d-flex flex-row '>
                                <div className='col-6 d-flex flex-column justify-content-center align-items-center'>
                                    <div className='image'></div>
                                    <div className='titleBenefit d-flex flex-column justify-content-center align-items-center'>
                                        <span>Tiếp cận</span>
                                        <span>
                                            Tiếp cận với khách hàng nhanh chóng
                                        </span>
                                    </div>
                                </div>
                                <div className='col-6  d-flex flex-column justify-content-center align-items-center'>
                                    <div className='image'></div>
                                    <div className='titleBenefit d-flex flex-column justify-content-center align-items-center'>
                                        <span>Lợi ích 2</span>
                                        <span>
                                            Tiếp cận với khách hàng nhanh chóng
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='buttonConect d-flex flex-row justify-content-center align-items-center'>
                            <span>Kết nối ngay</span>
                            <Icon type='arrow-right' />
                        </div>
                    </div>
                    <div className='passion'>
                        <div className='titleHeader d-flex flex-column justify-content-center align-items-center'>
                            <span>Passion Led Us Here</span>
                            <span>
                                Ngoài đam mê với áo quần, Tailor Wings mong muốn
                                được đem giá trị về đúng người đã tạo ra nó.
                                Quần áo bạn mặc là do bàn tay của người thợ may
                                tạo ra, vì bạn trông thật tuyệt vời trong những
                                bộ cánh ấy, nên họ hoàn toàn xứng đáng nhận được
                                giá trị tương ứng. Hãy cùng Tailor Wings chắp
                                cho những đôi cánh chưa từng được bay lên -
                                những người thợ may tận tụy.
                            </span>
                        </div>
                        <div className='video'></div>
                        <hr />
                    </div>
                </div>
                <div className='fit-menu-wraper d-flex flex-row justify-content-between align-items-center'>
                    <div className='icon d-flex flex-column justify-content-center align-items-center'>
                        <img src={tailor} alt='' />
                        <span>Trang chủ</span>
                    </div>
                    <div className='icon d-flex flex-column justify-content-center align-items-center'>
                        <Icon type='heart' />
                        <span>Đã Lưu</span>
                    </div>
                    <div className='icon d-flex flex-column justify-content-center align-items-center'>
                        <Icon type='shopping' />
                        <span>Giỏ Hàng</span>
                    </div>
                </div>
            </div>
        );
    }
}
